package com.bilal.dailyroutine

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.*

data class RoutineItem(val hour:Int, val minute:Int, val title:String, val subtitle:String, val icon:String = "")

class MainActivity : ComponentActivity() {
    private val routine = listOf(
        RoutineItem(12,0,"💻 Coding / Learning","Deep focus",),
        RoutineItem(13,30,"🍽️ Lunch + short rest","Recharge"),
        RoutineItem(14,0,"🕌 Namaz / Ibadat","Prayer"),
        RoutineItem(14,30,"💻 Coding / Learning","Practice / project"),
        RoutineItem(16,0,"🎬 YouTube Work","Video creation / editing"),
        RoutineItem(16,30,"📱 Free Time","Refresh"),
        RoutineItem(17,0,"🕌 Namaz / Ibadat","Prayer"),
        RoutineItem(17,30,"🎬 YouTube Work","Script + AI video + editing"),
        RoutineItem(18,45,"🕌 Namaz / Ibadat","Prayer"),
        RoutineItem(19,30,"🎬 YouTube Work","Upload + title + thumbnail"),
        RoutineItem(20,0,"🍽️ Dinner + Free Time","Wind down")
    )
    private val night = listOf(
        RoutineItem(1,0,"🌙 Tahajjud","Night prayer"),
        RoutineItem(4,50,"🌅 Fajr","Fajr prayer")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        render()
        findViewById<Button>(R.id.reminderButton).setOnClickListener { enableReminders() }
    }

    private fun render() {
        val now = Calendar.getInstance()
        findViewById<TextView>(R.id.dateText).text =
            SimpleDateFormat("EEEE, dd MMMM yyyy • hh:mm a", Locale.getDefault()).format(now.time)

        val all = (routine + night).sortedWith(compareBy<RoutineItem>{it.hour}.thenBy{it.minute})
        val currentMinutes = now.get(Calendar.HOUR_OF_DAY)*60 + now.get(Calendar.MINUTE)
        var current: RoutineItem? = null
        var next: RoutineItem? = null
        for (item in all) {
            val m = item.hour*60 + item.minute
            if (m <= currentMinutes) current = item
            else if (next == null) next = item
        }
        findViewById<TextView>(R.id.currentTask).text =
            current?.let { "${it.icon} ${it.title}" } ?: "🌙 Routine complete"
        findViewById<TextView>(R.id.nextTask).text =
            next?.let { "NEXT: ${formatTime(it)} • ${it.title}" } ?: "NEXT: Tomorrow • 12:00 PM"

        val sc = findViewById<LinearLayout>(R.id.scheduleContainer)
        val nc = findViewById<LinearLayout>(R.id.nightContainer)
        sc.removeAllViews(); nc.removeAllViews()
        routine.forEach { addItem(sc,it) }
        night.forEach { addItem(nc,it) }
    }

    private fun addItem(container: LinearLayout, item: RoutineItem) {
        val tv = TextView(this)
        tv.text = "${formatTime(item)}    ${item.icon} ${item.title}\n                 ${item.subtitle}"
        tv.setTextColor(ContextCompat.getColor(this,R.color.text))
        tv.textSize = 16f
        tv.setPadding(16,18,16,18)
        tv.setBackgroundResource(R.drawable.card)
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0,0,0,10)
        container.addView(tv,lp)
    }

    private fun formatTime(i:RoutineItem):String {
        val h = if (i.hour%12==0) 12 else i.hour%12
        return String.format(Locale.getDefault(),"%02d:%02d %s",h,i.minute,if(i.hour<12)"AM" else "PM")
    }

    private fun enableReminders() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),10)
        }
        if (Build.VERSION.SDK_INT >= 31) {
            val am = getSystemService(AlarmManager::class.java)
            if (!am.canScheduleExactAlarms()) {
                startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            }
        }
        val all = routine + night
        all.forEachIndexed { index,item -> schedule(item,index) }
        findViewById<TextView>(R.id.status).text = "✅ Reminders enabled. Your phone will play the notification sound at each scheduled time."
    }

    private fun schedule(item:RoutineItem,id:Int) {
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this,ReminderReceiver::class.java).apply {
            putExtra("title",item.title)
            putExtra("subtitle",item.subtitle)
        }
        val pi = PendingIntent.getBroadcast(this,id,intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY,item.hour); set(Calendar.MINUTE,item.minute); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0)
            if (before(Calendar.getInstance())) add(Calendar.DAY_OF_YEAR,1)
        }
        if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
        else am.setExact(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
    }
}
