package com.bilal.dailyroutine

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import androidx.core.app.NotificationCompat
import java.util.*

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val channelId = "bilal_routine"
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(channelId,"Bilal Routine Reminders",NotificationManager.IMPORTANCE_HIGH).apply {
                description = "Routine reminders with sound"
                setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),null)
                enableVibration(true)
            }
            nm.createNotificationChannel(ch)
        }
        val title = intent.getStringExtra("title") ?: "Bilal Daily Routine"
        val subtitle = intent.getStringExtra("subtitle") ?: "It's time for your task."
        val notification = NotificationCompat.Builder(context,channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("⏰ $title")
            .setContentText(subtitle)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
            .build()
        nm.notify(Random().nextInt(),notification)
    }
}
